const STATIC_SITE = false;
const $ = (selector) => document.querySelector(selector);
const locale = 'fa-IR';
const number = (value, decimals = 0) => new Intl.NumberFormat(locale, { maximumFractionDigits: decimals }).format(value);
const yearText = (year) => new Intl.NumberFormat(locale, { useGrouping: false }).format(year);
const palette = { POL: '#aa1d22', PRT: '#426653', WLD: '#657189' };
const labels = { POL: 'لهستان', PRT: 'پرتغال', WLD: 'جهان' };
const dots = { POL: 'pl', PRT: 'pt', WLD: 'world' };
const countries = ['POL', 'PRT'];
const snapshots = ['gdp', 'gdpPerCapita', 'exportShare'];
const state = { metric: 'exports', pair: 'rd', start: 2006, end: 2025, mode: 'trend', events: false, benchmark: 'mean' };
let catalog, dataset, visibleMetrics, chartYear;
let assistantReady = false;

const metric = (key) => catalog.metrics[key];
const series = (key) => dataset.series[key];
const raw = (key, country, year) => series(key).values[country][year] ?? null;
const finite = (value) => typeof value === 'number' && Number.isFinite(value);
const format = (value, key, growth = false) => {
  if (!finite(value)) return '—';
  const m = metric(key);
  return growth ? number(value, 2) + '٪' : number(value / m.scale, m.decimals) + (m.percent ? '٪' : '');
};
const element = (tag, text, className) => {
  const el = document.createElement(tag);
  if (text !== undefined) el.textContent = text;
  if (className) el.className = className;
  return el;
};
const link = (title, href) => {
  const el = element('a', title);
  el.href = href;
  el.target = '_blank';
  el.rel = 'noopener noreferrer';
  return el;
};
const viewYears = () => dataset.years.filter((y) => y >= state.start && y <= state.end);

function getValue(key, country, year) {
  if (country === 'WLD' && state.benchmark === 'mean') return series(key).worldMean[year]?.value ?? null;
  const value = raw(key, country, year);
  if (state.mode !== 'growth') return value;
  const previous = raw(key, country, year - 1);
  return finite(value) && finite(previous) && previous !== 0 ? (value / previous - 1) * 100 : null;
}

function chooseMetric(key) {
  state.metric = key;
  if (state.pair === key) state.pair = visibleMetrics.find((item) => item !== key);
  draw();
}

function renderSnapshot() {
  $('#snapshot').replaceChildren(...snapshots.map((key) => {
    const button = element('button', undefined, 'stat');
    button.type = 'button';
    const title = element('span', metric(key).short, 'stat-title');
    const arrow = element('span', '↙', 'stat-arrow');
    arrow.setAttribute('aria-hidden', 'true');
    title.append(arrow);
    const values = element('span', undefined, 'stat-values');
    for (const country of countries) {
      const value = element('span', undefined, 'stat-value');
      const name = element('small', labels[country]);
      name.prepend(element('i', undefined, 'dot ' + dots[country]));
      value.append(name, format(raw(key, country, 2024), key));
      values.append(value);
    }
    button.append(title, values, element('small', metric(key).unit, 'quiet'));
    button.addEventListener('click', () => {
      chooseMetric(key);
      $('#dashboard').scrollIntoView();
    });
    const card = element('div', undefined, 'stat-card');
    const source = link('منبع ↗', series(key).source);
    source.className = 'stat-source';
    source.setAttribute('aria-label', 'منبع ' + metric(key).short);
    card.append(button, source);
    return card;
  }));
}

function populateControls() {
  const list = $('#metric-list');
  visibleMetrics.forEach((key, index) => {
    const button = element('button', metric(key).short);
    button.type = 'button';
    button.dataset.metric = key;
    button.append(element('span', number(index + 1)));
    button.addEventListener('click', () => chooseMetric(key));
    list.append(button);
  });
  for (const [id, other] of [['start', 'end'], ['end', 'start']]) {
    const select = $('#' + id);
    select.append(...dataset.years.map((year) => new Option(yearText(year), year)));
    select.value = state[id];
    select.addEventListener('change', () => {
      state[id] = Number(select.value);
      if (state.start > state.end) state[other] = state[id];
      draw();
    });
  }
  $('#modes').addEventListener('click', (event) => {
    const button = event.target.closest('[data-mode]');
    if (button) {
      state.mode = button.dataset.mode;
      draw();
    }
  });
  $('#pair').addEventListener('change', (event) => {
    state.pair = event.target.value;
    draw();
  });
  $('#events').addEventListener('change', (event) => {
    state.events = event.target.checked;
    draw();
  });
  $('#benchmark').addEventListener('change', (event) => {
    state.benchmark = event.target.value;
    draw();
  });
}

function draw() {
  const { metric: key, mode } = state;
  const config = metric(key);
  $('#metric-title').textContent = config.title;
  $('#metric-unit').textContent = mode === 'growth' ? 'درصد تغییر نسبت به سال قبل' : config.unit;
  $('#metric-link').href = series(key).source;
  $('#start').value = state.start;
  $('#end').value = state.end;
  for (const button of document.querySelectorAll('[data-metric]')) button.setAttribute('aria-pressed', button.dataset.metric === key);
  for (const button of document.querySelectorAll('[data-mode]')) button.setAttribute('aria-pressed', button.dataset.mode === mode);
  const isCorrelation = mode === 'correlation';
  $('#pair-label').hidden = !isCorrelation;
  $('#benchmark-label').hidden = mode !== 'world';
  $('#events-toggle').hidden = isCorrelation;
  $('#pair').replaceChildren(...visibleMetrics.filter((item) => item !== key).map((item) => new Option(metric(item).short, item)));
  $('#pair').value = state.pair;
  const years = viewYears();
  const displayed = mode === 'world' ? [...countries, 'WLD'] : countries;
  $('#legend').replaceChildren(...displayed.map((country) => {
    const text = country === 'WLD' ? (state.benchmark === 'mean' ? 'میانگین کشورها' : 'سری رسمی جهان') : labels[country];
    const label = element('span', text);
    label.prepend(element('i', undefined, 'dot ' + dots[country]));
    return label;
  }));
  const events = state.events && !isCorrelation ? catalog.events.filter((event) => years.includes(event.year)) : [];
  $('#event-list').hidden = events.length === 0;
  $('#event-list').replaceChildren(...events.map((event) => link(yearText(event.year) + ' · ' + event.title, event.source)));
  const chart = $('#chart');
  chart.replaceChildren();
  chart.removeAttribute('tabindex');
  chart.onpointermove = chart.onpointerleave = chart.onfocus = chart.onblur = chart.onkeydown = null;
  if (isCorrelation) scatter(years);
  else lines(years, displayed, events);
  renderTable(years, displayed);
}

function geometry(values, zero = false) {
  let min = Math.min(...values), max = Math.max(...values);
  if (zero) {
    min = Math.min(0, min);
    max = Math.max(0, max);
  }
  const range = max - min || Math.abs(max) * .2 || 1;
  return [min - range * .08, max + range * .08];
}
function svgElement(name, attributes, text) {
  const el = document.createElementNS('http://www.w3.org/2000/svg', name);
  for (const [key, value] of Object.entries(attributes)) el.setAttribute(key, value);
  if (text !== undefined) el.textContent = text;
  return el;
}
function newPlot(w, h, label) {
  return svgElement('svg', { viewBox: '0 0 ' + w + ' ' + h, role: 'img', 'aria-label': label, direction: 'ltr' });
}

function lines(years, displayed, events) {
  const { metric: key, mode } = state;
  const chart = $('#chart');
  const values = displayed.flatMap((country) => years.map((year) => getValue(key, country, year))).filter(finite);
  const growth = mode === 'growth';
  const notes = growth ? ['تغییر سالانه از دو مشاهدهٔ متوالی محاسبه می‌شود.'] : [];
  if (mode === 'world') {
    notes.push(state.benchmark === 'mean'
      ? 'میانگین سادهٔ اقتصادهای دارای داده در هر سال. تعداد اقتصادها در راهنما و جدول آمده است.'
      : 'سری رسمی جهان با روش تجمیع منبع. برای شاخص‌های حجمی، این سری مجموع جهانی است.');
    if (!years.some((year) => finite(getValue(key, 'WLD', year)))) notes.push('برای جهان در این بازه داده‌ای وجود ندارد.');
  }
  if (events.length) notes.push('خط‌های رویداد زمینهٔ تاریخی‌اند.');
  notes.push('گسست خط نشان‌دهندهٔ فقدان داده است.');
  $('#chart-note').textContent = notes.join(' ');
  if (!values.length) {
    chart.append(element('p', 'داده‌ای در بازهٔ انتخاب‌شده وجود ندارد.', 'chart-empty'));
    return;
  }
  const w = 780, h = 250, left = 68, right = 20, top = 13, bottom = 27;
  const x = (index) => years.length === 1 ? (w + left - right) / 2 : left + index / (years.length - 1) * (w - left - right);
  const [min, max] = geometry(values, growth);
  const y = (value) => top + (max - value) / (max - min) * (h - top - bottom);
  const plot = newPlot(w, h, metric(key).title + '، ' + labels.POL + ' و ' + labels.PRT);
  for (let i = 0; i <= 4; i++) {
    const value = min + (max - min) * i / 4;
    const yy = y(value);
    plot.append(svgElement('line', { x1: left, x2: w - right, y1: yy, y2: yy, class: 'grid' }));
    const precision = (max - min) / (growth ? 1 : metric(key).scale) < 12 ? 1 : 0;
    plot.append(svgElement('text', { x: left - 8, y: yy + 4, 'text-anchor': 'end' },
      number(value / (growth ? 1 : metric(key).scale), precision) + (growth || metric(key).percent ? '٪' : '')));
  }
  const indices = new Set(Array.from({ length: Math.min(years.length, 6) }, (_, i) => Math.round(i * (years.length - 1) / Math.max(1, Math.min(years.length, 6) - 1))));
  for (const i of indices) plot.append(svgElement('text', { x: x(i), y: h - 6, 'text-anchor': 'middle' }, yearText(years[i])));
  for (const event of events) {
    const xx = x(years.indexOf(event.year));
    plot.append(svgElement('line', { x1: xx, x2: xx, y1: top, y2: h - bottom, class: 'event-line' }));
    const point = svgElement('circle', { cx: xx, cy: top, r: 3, fill: '#a8a397' });
    point.append(svgElement('title', {}, event.title));
    plot.append(point);
  }
  for (const country of displayed) {
    let path = '', previous = false;
    for (const [index, year] of years.entries()) {
      const value = getValue(key, country, year);
      if (!finite(value)) { previous = false; continue; }
      path += (previous ? ' L' : ' M') + x(index) + ' ' + y(value);
      if (!previous && !finite(getValue(key, country, years[index + 1]))) {
        plot.append(svgElement('circle', { cx: x(index), cy: y(value), r: 3, fill: palette[country] }));
      }
      previous = true;
    }
    if (path) plot.append(svgElement('path', { d: path, class: 'series', stroke: palette[country], 'stroke-dasharray': country === 'WLD' ? '5 4' : 'none' }));
  }
  const cursor = svgElement('line', { x1: 0, x2: 0, y1: top, y2: h - bottom, class: 'cursor', visibility: 'hidden' });
  plot.append(cursor);
  const tip = element('div', undefined, 'chart-tooltip');
  tip.hidden = true;
  const position = (i) => {
    chartYear = years[i];
    const xx = x(i);
    cursor.setAttribute('x1', xx);
    cursor.setAttribute('x2', xx);
    cursor.setAttribute('visibility', 'visible');
    tip.hidden = false;
    tip.style.left = Math.min(xx / w * 100, 58) + '%';
    tip.replaceChildren(element('b', yearText(years[i])));
    for (const country of displayed) {
      const sample = country === 'WLD' && state.benchmark === 'mean' ? series(key).worldMean[years[i]]?.n : null;
      const label = country === 'WLD' && sample != null ? 'میانگین جهان (' + number(sample) + ' اقتصاد)' : labels[country];
      tip.append(element('div', label + ' · ' + format(getValue(key, country, years[i]), key, growth)));
    }
  };
  chart.tabIndex = 0;
  chart.onpointermove = (event) => {
    const rect = plot.getBoundingClientRect();
    const xx = (event.clientX - rect.left) / rect.width * w;
    const i = years.length === 1 ? 0 : Math.round((xx - left) / (w - left - right) * (years.length - 1));
    position(Math.max(0, Math.min(years.length - 1, i)));
  };
  chart.onfocus = () => position(Math.max(0, years.indexOf(chartYear)));
  chart.onkeydown = (event) => {
    if (!['ArrowLeft', 'ArrowRight'].includes(event.key)) return;
    event.preventDefault();
    const i = Math.max(0, years.indexOf(chartYear)) + (event.key === 'ArrowRight' ? 1 : -1);
    position(Math.max(0, Math.min(years.length - 1, i)));
  };
  chart.onpointerleave = chart.onblur = () => {
    cursor.setAttribute('visibility', 'hidden');
    tip.hidden = true;
  };
  chart.append(plot, tip);
}

function pairedData(country, years) {
  return years.map((year) => [raw(state.metric, country, year), raw(state.pair, country, year), year])
    .filter(([x, y]) => finite(x) && finite(y));
}
function pearson(points) {
  if (points.length < 3) return null;
  const n = points.length;
  const mx = points.reduce((sum, point) => sum + point[0], 0) / n;
  const my = points.reduce((sum, point) => sum + point[1], 0) / n;
  let xx = 0, yy = 0, xy = 0;
  for (const [x, y] of points) {
    xx += (x - mx) ** 2;
    yy += (y - my) ** 2;
    xy += (x - mx) * (y - my);
  }
  return xx && yy ? xy / Math.sqrt(xx * yy) : null;
}

function scatter(years) {
  const chart = $('#chart');
  const group = element('div', undefined, 'correlation-grid');
  const all = countries.flatMap((country) => pairedData(country, years));
  $('#chart-note').textContent = 'ضریب پیرسون برای سال‌های دارای داده در هر دو شاخص. روند مشترک زمانی می‌تواند ضریب را بالا ببرد. محور افقی، شاخص اول است.';
  for (const country of countries) {
    const points = pairedData(country, years);
    const box = element('section', undefined, 'scatter');
    const r = pearson(points);
    box.append(element('h4', labels[country]), element('p',
      (r == null ? 'ضریب در دسترس نیست' : 'ضریب ' + number(r, 3)) + ' · ' + number(points.length) + ' سال مشترک'));
    if (points.length) {
      const plot = newPlot(325, 180, 'نمودار پراکنش ' + labels[country]);
      const [minX, maxX] = geometry(all.map((p) => p[0]));
      const [minY, maxY] = geometry(all.map((p) => p[1]));
      plot.append(svgElement('path', { d: 'M46 12V147H316', class: 'grid', fill: 'none' }));
      for (const [v, i] of [[minX, 0], [maxX, 1]]) plot.append(svgElement('text', { x: 46 + i * 267, y: 164, 'text-anchor': i ? 'end' : 'middle' }, format(v, state.metric)));
      for (const [v, i] of [[minY, 0], [maxY, 1]]) plot.append(svgElement('text', { x: 43, y: 144 - i * 124, 'text-anchor': 'end' }, format(v, state.pair)));
      for (const [a, b, year] of points) {
        const point = svgElement('circle', { cx: 46 + (a - minX) / (maxX - minX) * 267,
          cy: 147 - (b - minY) / (maxY - minY) * 135, r: 4, fill: palette[country], opacity: .7 });
        point.append(svgElement('title', {}, yearText(year) + ' · ' + format(a, state.metric) + ' / ' + format(b, state.pair)));
        plot.append(point);
      }
      box.append(plot);
    }
    group.append(box);
  }
  chart.append(group);
}

function renderTable(years, displayed) {
  const table = element('table');
  const head = element('thead'), body = element('tbody');
  const growth = state.mode === 'growth';
  const correlation = state.mode === 'correlation';
  const showCount = state.mode === 'world' && state.benchmark === 'mean';
  const columns = ['سال', ...displayed.map((country) => country === 'WLD' && showCount ? 'میانگین کشورها' : labels[country])];
  if (correlation) columns.push(...countries.map((country) => labels[country] + ' · شاخص دوم'));
  if (showCount) columns.push('تعداد اقتصادها');
  const header = element('tr');
  for (const value of columns) {
    const th = element('th', value);
    th.scope = 'col';
    header.append(th);
  }
  head.append(header);
  for (const year of years.slice().reverse()) {
    const row = element('tr');
    const values = [yearText(year), ...displayed.map((country) => format(getValue(state.metric, country, year), state.metric, growth))];
    if (correlation) values.push(...countries.map((country) => format(raw(state.pair, country, year), state.pair)));
    if (showCount) values.push(number(series(state.metric).worldMean[year]?.n ?? 0));
    row.append(...values.map((value) => element('td', value)));
    body.append(row);
  }
  table.append(head, body);
  $('#table').replaceChildren(table);
}

function renderSources() {
  const list = element('ul');
  const descriptions = [
    'میانگین جهان، میانگین سادهٔ اقتصادهای دارای مشاهده در هر سال است و با مجموع یا نسبت تجمیعی جهان تفاوت دارد.',
    'نرخ تغییر سالانه برابر تغییر نسبی مقدار نسبت به سال قبل است. دادهٔ مفقود با خط تیره و گسست نمودار نمایش داده می‌شود.',
    'سری بدهی از صندوق بین‌المللی پول تا ۲۰۲۴ نمایش داده می‌شود. سایر سری‌ها از بانک جهانی‌اند. سال‌ها میلادی‌اند.'
  ];
  for (const key of visibleMetrics) {
    const item = element('li');
    item.append(link(metric(key).title + ' ↗', series(key).source), ' · ' + metric(key).definition);
    list.append(item);
  }
  $('#source-body').replaceChildren(...descriptions.map((text) => element('p', text)), list);
}

function download() {
  const keys = [...visibleMetrics, 'population'];
  const lines = ['year,indicator,country,value,world_mean_n,source_code'];
  for (const year of viewYears()) for (const key of keys) {
    for (const country of [...countries, 'WLD']) lines.push([year, key, country, raw(key, country, year) ?? '', '', series(key).code].join(','));
    const sample = series(key).worldMean[year];
    lines.push([year, key, 'MEAN', sample?.value ?? '', sample?.n ?? 0, series(key).code].join(','));
  }
  const url = URL.createObjectURL(new Blob([lines.join('\n') + '\n'], { type: 'text/csv;charset=utf-8' }));
  const anchor = element('a');
  anchor.download = 'poland-portugal-' + state.start + '-' + state.end + '.csv';
  anchor.href = url;
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}


function normalizeQuestion(value) {
  return value.toLowerCase().replace(/[يك]/g, (letter) => letter === 'ي' ? 'ی' : 'ک')
    .replace(/[۰-۹]/g, (digit) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(digit)))
    .replace(/[٠-٩]/g, (digit) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(digit)))
    .replace(/‌/g, ' ');
}

function staticAnswer(question, prompt) {
  if (prompt && PAGE_CONTENT.presets[prompt]) return PAGE_CONTENT.presets[prompt];
  const query = normalizeQuestion(question);
  const ignored = new Set(['لهستان', 'پرتغال', 'شاخص', 'برای', 'چقدر', 'چیست', 'مقایسه', 'چگونه']);
  const terms = query.split(/[^\p{L}\p{N}&]+/u).filter((term) => term.length > 1 && !ignored.has(term));
  const aliases = {
    gdp: ['تولید ناخالص', 'اندازه اقتصاد', 'gdp'],
    gdpPerCapita: ['سرانه', 'per capita'],
    exportShare: ['سهم صادرات', 'درصد صادرات'],
    exports: ['ارزش صادرات', 'صادرات'],
    rd: ['تحقیق و توسعه', 'پژوهش', 'r&d'],
    patents: ['اختراع', 'پتنت'],
    articles: ['مقاله', 'مقالات'],
    gini: ['جینی', 'نابرابری'],
    debt: ['بدهی'],
    population: ['جمعیت']
  };
  const matches = Object.entries(catalog.metrics).map(([key, info]) => {
    const text = normalizeQuestion(info.title + ' ' + info.tags + ' ' + info.definition);
    let score = terms.filter((word) => text.includes(word)).length;
    if ((aliases[key] || []).some((word) => query.includes(word))) score += 5;
    if (key === 'gdp' && query.includes('سرانه')) score -= 5;
    if (key === 'exports' && query.includes('سهم')) score -= 5;
    return { key, score };
  }).filter((item) => item.score > 0).sort((a, b) => b.score - a.score);
  const threshold = Math.max(3, (matches[0]?.score || 0) * .6);
  matches.splice(0, matches.length, ...matches.filter((item) => item.score >= threshold).slice(0, 3));
  if (!matches.length) return {answer:'نام شاخص، کشور و سال را در سؤال بنویسید یا یکی از سه پرسش پیشنهادی را انتخاب کنید.',mode:'local',sources:[]};
  const requestedYears = [...new Set(query.match(/\b20\d{2}\b/g) || [])].map(Number);
  const selected = countries.filter((country) => query.includes(labels[country]));
  const requestedCountries = selected.length ? selected : countries;
  const sources = [];
  const parts = matches.map(({key}, index) => {
    sources.push({id:index + 1,title:metric(key).title,url:series(key).source});
    const header = metric(key).title + ' [' + number(index + 1) + ']';
    if (/تعریف|چیست|یعنی|محاسبه/.test(query) && !requestedYears.length) return header + '\n' + metric(key).definition;
    const common = dataset.years.filter((year) => year >= state.start && year <= state.end &&
      requestedCountries.every((country) => finite(raw(key,country,year))));
    const range = /روند|رشد|تغییر/.test(query);
    const years = requestedYears.length ? requestedYears.slice(0,6) :
      (range && common.length > 1 ? [common[0],common.at(-1)] : common.slice(-1));
    const rows = years.map((year) => yearText(year) + ' · ' + requestedCountries.map((country) =>
      labels[country] + ' ' + format(raw(key,country,year),key)).join('، '));
    return header + ' · ' + metric(key).unit + '\n' +
      (rows.join('\n') || 'در این بازه دادهٔ مشترک موجود نیست.');
  });
  return {answer:parts.join('\n\n'),mode:'local',sources};
}

function openAssistant() {
  const dialog = $('#assistant');
  if (!dialog.open) dialog.showModal();
  $('#question').focus();
}
function addMessage(text, className, sources = []) {
  const log = $('#messages');
  const message = element('div', text, 'message ' + className);
  if (sources.length) {
    const links = element('div', undefined, 'answer-links');
    sources.filter((source) => /^https:\/\//.test(source.url)).forEach((source, index) => links.append(link('[' + number(source.id ?? index + 1) + '] ' + source.title, source.url)));
    message.append(links);
  }
  log.append(message);
  log.scrollTop = log.scrollHeight;
  return message;
}
async function ask(question, prompt = null) {
  if (!assistantReady || !question.trim()) return;
  assistantReady = false;
  const controls = document.querySelectorAll('#ask-form button, #questions button');
  controls.forEach((button) => button.disabled = true);
  addMessage(question, 'user');
  const useAi = $('#use-ai').checked;
  $('#use-ai').checked = false;
  const pending = addMessage(useAi ? 'در حال تحلیل…' : 'در حال بازیابی داده‌ها…', 'reply');
  try {
    const response = STATIC_SITE ? null : await fetch('/api/ask', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question, prompt, metric: state.metric, start: state.start, end: state.end, use_ai: useAi })
    });
    const result = STATIC_SITE ? staticAnswer(question, prompt) : await response.json();
    if (response && !response.ok) throw new Error();
    pending.remove();
    addMessage(result.answer, 'reply', result.sources);
    const status = {
      gapgpt: 'پاسخ هوشمند با منابع داشبورد',
      fallback: 'پاسخ محلی · ارتباط با دستیار برقرار نشد',
      limit: 'پاسخ محلی · سقف درخواست این نوبت پر شد'
    };
    $('#assistant-status').textContent = status[result.mode] || 'پاسخ مستند محلی';
  } catch {
    pending.textContent = 'پاسخ دریافت نشد. دوباره تلاش کنید.';
  } finally {
    assistantReady = true;
    controls.forEach((button) => button.disabled = false);
  }
}
function setupAssistant() {
  $('#questions').replaceChildren(...catalog.prompts.map((prompt, index) => {
    const button = element('button', prompt.title);
    button.type = 'button';
    button.prepend(element('span', number(index + 1)));
    button.addEventListener('click', () => ask(prompt.question, prompt.id));
    return button;
  }));
  assistantReady = true;
  $('#ask-form').addEventListener('submit', (event) => {
    event.preventDefault();
    const input = $('#question');
    if (!input.value.trim() || !assistantReady) return;
    ask(input.value.trim());
    input.value = '';
  });
  if (STATIC_SITE) return;
  fetch('/api/status').then((response) => response.json()).then(({ gapgpt }) => {
    $('#ai-controls').hidden = !gapgpt;
    $('#assistant-status').textContent = 'پاسخ مستند محلی';
  }).catch(() => {});
}

document.querySelectorAll('.ask-open').forEach((button) => button.addEventListener('click', openAssistant));
$('.close').addEventListener('click', () => $('#assistant').close());
$('a[href="#sources"]').addEventListener('click', () => $('#sources').open = true);
document.addEventListener('scroll', () => {
  const remaining = document.documentElement.scrollHeight - innerHeight;
  $('.progress').style.transform = 'scaleX(' + (remaining > 0 ? scrollY / remaining : 0) + ')';
}, { passive: true });

async function load() {
  const status = $('#load-status');
  try {
    [catalog, dataset] = await Promise.all(['/data/catalog.json', '/data/series.json'].map(async (url) => {
      const response = await fetch(url);
      if (!response.ok) throw new Error();
      return response.json();
    }));
    visibleMetrics = Object.keys(catalog.metrics).filter((key) => key !== 'population');
    populateControls();
    renderSnapshot();
    renderSources();
    setupAssistant();
    draw();
    $('#workspace').hidden = false;
    $('#download').addEventListener('click', download);
    status.hidden = true;
  } catch (error) {
    console.error(error);
    status.textContent = 'بارگذاری داده‌ها ممکن نشد. صفحه را دوباره باز کنید.';
  }
}
load();
