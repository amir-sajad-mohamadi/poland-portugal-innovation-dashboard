"""Web server for the dashboard. Uses only the Python standard library."""
import argparse
import json
import logging
import mimetypes
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

from assistant import ask, configured

ROOT = Path(__file__).resolve().parent
STATIC = ROOT / 'public'
MIME_TYPES = {'.js': 'text/javascript', '.woff2': 'font/woff2', '.json': 'application/json'}


def read_settings():
    path = ROOT / '.env'
    if not path.is_file():
        return
    for line in path.read_text().splitlines():
        key, sep, value = line.partition('=')
        if sep and key.strip() in {'GAPGPT_API_KEY', 'GAPGPT_MODEL'}:
            os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


class Handler(BaseHTTPRequestHandler):
    def send_bytes(self, status, data, mime):
        self.send_response(status)
        self.send_header('Content-Type', mime)
        self.send_header('Content-Length', len(data))
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Content-Security-Policy', "default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:; font-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        if self.command != 'HEAD':
            self.wfile.write(data)

    def send_json(self, status, result):
        self.send_bytes(status, json.dumps(result, ensure_ascii=False).encode(), 'application/json; charset=utf-8')

    def do_GET(self):
        path = urlsplit(self.path).path
        if path == '/api/status':
            return self.send_json(200, {'gapgpt': configured()})
        if path in {'/data/series.json', '/data/catalog.json'}:
            file = ROOT / path.lstrip('/')
        else:
            file = (STATIC / path.lstrip('/')).resolve() if path != '/' else STATIC / 'index.html'
            if not file.is_relative_to(STATIC) or (file.parent != STATIC and file.parent != STATIC / 'assets'):
                return self.send_json(404, {'error': 'صفحه پیدا نشد.'})
        if not file.is_file() or file.name.startswith('.'):
            return self.send_json(404, {'error': 'صفحه پیدا نشد.'})
        mime = MIME_TYPES.get(file.suffix) or mimetypes.guess_type(file)[0] or 'application/octet-stream'
        if mime.startswith('text/') or mime == 'application/json':
            mime += '; charset=utf-8'
        self.send_bytes(200, file.read_bytes(), mime)

    do_HEAD = do_GET

    def do_POST(self):
        if urlsplit(self.path).path != '/api/ask':
            return self.send_json(404, {'error': 'صفحه پیدا نشد.'})
        origin = self.headers.get('Origin')
        allowed = {f'http://localhost:{self.server.server_port}', f'http://127.0.0.1:{self.server.server_port}'}
        if origin and origin not in allowed:
            return self.send_json(403, {'error': 'درخواست از مبدأ دیگری ارسال شده است.'})
        if self.headers.get_content_type() != 'application/json':
            return self.send_json(415, {'error': 'قالب درخواست معتبر نیست.'})
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if not 0 < size <= 12000:
                raise ValueError()
            self.send_json(200, ask(json.loads(self.rfile.read(size))))
        except (ValueError, UnicodeError):
            self.send_json(400, {'error': 'متن درخواست معتبر نیست.'})


if __name__ == '__main__':
    read_settings()
    logging.basicConfig(level=logging.INFO, format='%(message)s')
    parser = argparse.ArgumentParser()
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', default=8765, type=int)
    args = parser.parse_args()
    with ThreadingHTTPServer((args.host, args.port), Handler) as server:
        print(f'http://{args.host}:{server.server_port}', flush=True)
        server.serve_forever()
