"""Build a self-contained dashboard for GitHub Pages."""
import base64
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from assistant import ask

catalog = json.loads((ROOT / 'data/catalog.json').read_text())
series = json.loads((ROOT / 'data/series.json').read_text())
presets = {item['id']: ask({'question': item['question'], 'prompt': item['id']})
           for item in catalog['prompts']}
(ROOT / 'public/reference.json').write_text(json.dumps(presets, ensure_ascii=False))
css = (ROOT / 'public/styles.css').read_text()
for name in ('Vazirmatn-arabic.woff2', 'Vazirmatn-latin.woff2'):
    encoded = base64.b64encode((ROOT / 'public/assets' / name).read_bytes()).decode()
    css = css.replace('/assets/' + name, 'data:font/woff2;base64,' + encoded)

app = (ROOT / 'public/app.js').read_text()
app = app.replace("const STATIC_SITE = false;", "const STATIC_SITE = true;")
start = app.index("    [catalog, dataset] = await Promise.all(")
end = app.index("    visibleMetrics =", start)
app = app[:start] + "    [catalog, dataset] = [PAGE_CATALOG, PAGE_DATA];\n" + app[end:]
embedded = json.dumps({'catalog': catalog, 'data': series, 'presets': presets}, ensure_ascii=False, separators=(',', ':'))
embedded = embedded.replace('<', '\\u003c')
script = 'const PAGE_CONTENT = ' + embedded + ';\nconst PAGE_CATALOG = PAGE_CONTENT.catalog;\nconst PAGE_DATA = PAGE_CONTENT.data;\n' + app
html = (ROOT / 'public/index.html').read_text()
html = html.replace('<link rel="stylesheet" href="/styles.css">', '<style>' + css + '</style>')
html = html.replace('<script src="/app.js" type="module"></script>', '<script type="module">' + script + '</script>')
target = ROOT / 'docs'
target.mkdir(exist_ok=True)
(target / 'index.html').write_text(html)
(target / '.nojekyll').touch()
print(f'Pages bundle ready ({len(html.encode())} bytes)')
