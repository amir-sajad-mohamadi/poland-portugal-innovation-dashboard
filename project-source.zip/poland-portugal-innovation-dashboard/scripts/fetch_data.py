"""Refresh the public-source data used by the dashboard."""
import csv
import json
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from io import BytesIO, TextIOWrapper
from pathlib import Path
from statistics import mean
from urllib.parse import urlencode
from urllib.request import urlopen
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
YEARS = range(2004, 2026)
COUNTRIES = ('POL', 'PRT', 'WLD')
WDI = {
    'patents': 'IP.PAT.RESD', 'articles': 'IP.JRN.ARTC.SC',
    'rd': 'GB.XPD.RSDV.GD.ZS', 'exports': 'TX.VAL.TECH.CD',
    'gini': 'SI.POV.GINI', 'gdpPerCapita': 'NY.GDP.PCAP.PP.CD',
    'gdp': 'NY.GDP.MKTP.PP.CD', 'exportShare': 'TX.VAL.TECH.MF.ZS',
    'population': 'SP.POP.TOTL',
    'nominalGdp': 'NY.GDP.MKTP.CD', 'realGrowth': 'NY.GDP.MKTP.KD.ZG',
    'realPpp': 'NY.GDP.PCAP.PP.KD', 'investment': 'NE.GDI.FTOT.ZS',
    'fdi': 'BX.KLT.DINV.WD.GD.ZS', 'manufacturing': 'NV.IND.MANF.ZS',
    'manufacturingGrowth': 'NV.IND.MANF.KD.ZG', 'totalExports': 'NE.EXP.GNFS.ZS',
    'ictExports': 'BX.GSR.CCIS.CD', 'ictShare': 'BX.GSR.CCIS.ZS',
    'researchers': 'SP.POP.SCIE.RD.P6', 'tertiary': 'SE.TER.ENRR',
    'internet': 'IT.NET.USER.ZS',
    'broadband': 'IT.NET.BBND.P2', 'employment': 'SL.EMP.TOTL.SP.ZS',
    'youthUnemployment': 'SL.UEM.1524.ZS', 'life': 'SP.DYN.LE00.IN',
    'renewables': 'EG.FEC.RNEW.ZS',
}


def get(url):
    for attempt in range(3):
        try:
            with urlopen(url, timeout=25) as response:
                return json.load(response)
        except (OSError, ValueError):
            if attempt == 2:
                raise
            time.sleep(1 + attempt)


def world_means(values, economies):
    return {
        str(year): {'value': mean(sample) if sample else None, 'n': len(sample)}
        for year in YEARS
        for sample in [[rows[str(year)] for key, rows in values.items()
                        if key in economies and rows.get(str(year)) is not None]]
    }


EUROSTAT = {
    'education': ('gov_10a_exp', {'cofog99': 'GF09', 'sector': 'S13', 'na_item': 'TE', 'unit': 'PC_GDP'}),
    'businessRd': ('rd_e_gerdtot', {'sectperf': 'BES', 'unit': 'PC_GDP'}),
    'cloud': ('isoc_cicce_use', {'size_emp': 'GE10', 'indic_is': 'E_CC', 'unit': 'PC_ENT'}),
    'enterpriseAi': ('isoc_eb_ai', {'size_emp': 'GE10', 'indic_is': 'E_AI_TANY', 'unit': 'PC_ENT'}),
}


def wdi(item, archive=None):
    key, code = item
    url = f'https://api.worldbank.org/v2/en/indicator/{code}?downloadformat=csv'
    if archive is None:
        with urlopen(url, timeout=30) as response:
            archive = response.read()
    with ZipFile(BytesIO(archive)) as bundle:
        country_file = next(name for name in bundle.namelist() if name.startswith('Metadata_Country_'))
        with TextIOWrapper(bundle.open(country_file), encoding='utf-8-sig') as stream:
            economies = {row['Country Code'] for row in csv.DictReader(stream) if row['Region']}
        data_file = next(name for name in bundle.namelist() if name.startswith('API_'))
        with TextIOWrapper(bundle.open(data_file), encoding='utf-8-sig') as stream:
            reader = csv.reader(stream)
            next(reader)
            next(reader)
            updated = next(reader)[1]
            next(reader)
            observations = {
                row['Country Code']: {
                    str(year): float(row[str(year)]) if row.get(str(year)) else None
                    for year in YEARS
                } for row in csv.DictReader(stream)
            }
    return key, {'worldMean': world_means(observations, economies), 'meanUrl': url,
                 'provider': 'WDI', 'code': code, 'url': url,
                 'source': f'https://data.worldbank.org/indicator/{code}?locations=PL-PT',
                 'updated': updated,
                 'values': {country: observations.get(country, {}) for country in COUNTRIES}}


def eurostat(item, data=None):
    key, (code, filters) = item
    query = urlencode({'lang': 'en', 'geo': ['PL', 'PT', 'EU27_2020'], **filters}, doseq=True)
    url = f'https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/{code}?{query}'
    data = data if data is not None else get(url)
    dimensions = data['id']
    indices = {dim: data['dimension'][dim]['category']['index'] for dim in dimensions}
    values = {}
    for country, geo in zip(COUNTRIES, ['PL', 'PT', 'EU27_2020']):
        row = {}
        for year in YEARS:
            fields = {'geo': geo, 'time': str(year), **filters}
            if str(year) not in indices['time']:
                row[str(year)] = None
                continue
            offset = 0
            for dim, size in zip(dimensions, data['size']):
                category = fields.get(dim, next(iter(indices[dim])))
                offset = offset * size + indices[dim][category]
            row[str(year)] = data['value'].get(str(offset))
        values[country] = row
    return key, {'provider': 'Eurostat', 'code': code, 'url': url, 'regional': True,
                 'source': f'https://ec.europa.eu/eurostat/databrowser/view/{code}/default/table?lang=en',
                 'updated': data.get('updated'), 'worldMean': {}, 'values': values}


def debt(economies):
    code = 'GGXWDG_NGDP'
    url = f'https://www.imf.org/external/datamapper/api/v1/{code}/POL/PRT/WEOWORLD'
    data = get(url)['values'][code]
    values = {
        country: {str(year): data['WEOWORLD' if country == 'WLD' else country].get(str(year))
                  if year <= 2024 else None for year in YEARS}
        for country in COUNTRIES
    }
    world_mean = world_means(data, economies)
    world_mean['2025'] = {'value': None, 'n': 0}
    return 'debt', {'worldMean': world_mean, 'provider': 'IMF', 'code': code, 'url': url,
                    'source': f'https://www.imf.org/external/datamapper/{code}@WEO/POL/PRT/WEOWORLD',
                    'values': values}


def main():
    _, countries = get('https://api.worldbank.org/v2/country?format=json&per_page=400')
    economies = {country['id'] for country in countries if country['region']['id'] != 'NA'}
    with ThreadPoolExecutor(max_workers=8) as executor:
        debt_job = executor.submit(debt, economies)
        series = dict(executor.map(wdi, WDI.items()))
        series.update(executor.map(eurostat, EUROSTAT.items()))
        series.update([debt_job.result()])
    for key, item in series.items():
        for country in ('POL', 'PRT'):
            if not any(value is not None for value in item['values'][country].values()):
                raise ValueError(f'No data for {key}: {country}')
        print(key, {country: (len([v for v in vals.values() if v is not None]), vals.get('2024'))
                    for country, vals in item['values'].items()}, file=sys.stderr)
    target = ROOT / 'data' / 'series.json'
    temp = target.with_suffix('.tmp')
    temp.write_text(json.dumps({'years': list(YEARS), 'series': series}, ensure_ascii=False, separators=(',', ':')) + '\n')
    temp.replace(target)


if __name__ == '__main__':
    main()
