"""Refresh the public-source data used by the dashboard."""
import json
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from statistics import mean
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parents[1]
YEARS = range(2004, 2026)
COUNTRIES = ('POL', 'PRT', 'WLD')
WDI = {
    'patents': 'IP.PAT.RESD', 'articles': 'IP.JRN.ARTC.SC',
    'rd': 'GB.XPD.RSDV.GD.ZS', 'exports': 'TX.VAL.TECH.CD',
    'gini': 'SI.POV.GINI', 'gdpPerCapita': 'NY.GDP.PCAP.PP.CD',
    'gdp': 'NY.GDP.MKTP.PP.CD', 'exportShare': 'TX.VAL.TECH.MF.ZS',
    'population': 'SP.POP.TOTL',
}


def get(url):
    for attempt in range(3):
        try:
            with urlopen(url, timeout=25) as response:
                return json.load(response)
        except (OSError, ValueError):
            if attempt == 2:
                raise
            time.sleep(1 + attempt)


def world_means(values, economies):
    return {
        str(year): {'value': mean(sample) if sample else None, 'n': len(sample)}
        for year in YEARS
        for sample in [[rows[str(year)] for key, rows in values.items()
                        if key in economies and rows.get(str(year)) is not None]]
    }


def wdi(item, economies):
    key, code = item
    url = f'https://api.worldbank.org/v2/country/POL;PRT;WLD/indicator/{code}?format=json&date=2004:2025&per_page=100&source=2'
    meta, rows = get(url)
    if meta['pages'] != 1 or not isinstance(rows, list):
        raise ValueError(f'Invalid response for {code}')
    values = {country: {} for country in COUNTRIES}
    for row in rows:
        country = row['countryiso3code'] or ('WLD' if row['country']['value'] == 'World' else None)
        if country not in values or row['indicator']['id'] != code:
            raise ValueError(f'Unexpected observation for {code}')
        values[country][row['date']] = row['value']
    mean_url = url.replace('POL;PRT;WLD', 'all').replace('per_page=100', 'per_page=20000')
    mean_meta, mean_rows = get(mean_url)
    if mean_meta['pages'] != 1 or not isinstance(mean_rows, list):
        raise ValueError(f'Incomplete global coverage for {code}')
    global_values = {}
    for row in mean_rows:
        global_values.setdefault(row['countryiso3code'], {})[row['date']] = row['value']
    return key, {'worldMean': world_means(global_values, economies), 'meanUrl': mean_url, 'provider': 'WDI', 'code': code, 'url': url,
                 'source': f'https://data.worldbank.org/indicator/{code}?locations=PL-PT',
                 'updated': meta.get('lastupdated'), 'values': values}


def debt(economies):
    code = 'GGXWDG_NGDP'
    url = f'https://www.imf.org/external/datamapper/api/v1/{code}/POL/PRT/WEOWORLD'
    data = get(url)['values'][code]
    values = {
        country: {str(year): data['WEOWORLD' if country == 'WLD' else country].get(str(year))
                  if year <= 2024 else None for year in YEARS}
        for country in COUNTRIES
    }
    world_mean = world_means(data, economies)
    world_mean['2025'] = {'value': None, 'n': 0}
    return 'debt', {'worldMean': world_mean, 'provider': 'IMF', 'code': code, 'url': url,
                    'source': f'https://www.imf.org/external/datamapper/{code}@WEO/POL/PRT/WEOWORLD',
                    'values': values}


def main():
    _, countries = get('https://api.worldbank.org/v2/country?format=json&per_page=400')
    economies = {country['id'] for country in countries if country['region']['id'] != 'NA'}
    with ThreadPoolExecutor(max_workers=5) as executor:
        debt_job = executor.submit(debt, economies)
        series = dict(executor.map(lambda item: wdi(item, economies), WDI.items()))
        series.update([debt_job.result()])
    for key, item in series.items():
        for country in ('POL', 'PRT'):
            if not any(value is not None for value in item['values'][country].values()):
                raise ValueError(f'No data for {key}: {country}')
        print(key, {country: (len([v for v in vals.values() if v is not None]), vals.get('2024'))
                    for country, vals in item['values'].items()}, file=sys.stderr)
    target = ROOT / 'data' / 'series.json'
    temp = target.with_suffix('.tmp')
    temp.write_text(json.dumps({'years': list(YEARS), 'series': series}, ensure_ascii=False, separators=(',', ':')) + '\n')
    temp.replace(target)


if __name__ == '__main__':
    main()
